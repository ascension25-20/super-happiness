const express = require('express');
const nodemailer = require('nodemailer');
const path = require('path');
const dotenv = require('dotenv');
const bodyParser = require('body-parser');

dotenv.config();

const app = express();
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));

// Booking form route
app.post('/book', async (req, res) => {
  const { fullName, email, phone, checkIn, checkOut, guests, roomType } = req.body;

  const output = `
    <h3>New Booking Request</h3>
    <p><strong>Name:</strong> ${fullName}</p>
    <p><strong>Email:</strong> ${email}</p>
    <p><strong>Phone:</strong> ${phone}</p>
    <p><strong>Check-in:</strong> ${checkIn}</p>
    <p><strong>Check-out:</strong> ${checkOut}</p>
    <p><strong>Guests:</strong> ${guests}</p>
    <p><strong>Room Type:</strong> ${roomType}</p>
  `;

  let transporter = nodemailer.createTransport({
    service: 'gmail',
    auth: {
      user: process.env.MAIL_USER, 
      pass: process.env.MAIL_PASS
    }
  });

  try {
    await transporter.sendMail({
      from: `"Dotmot Hotel" <${process.env.MAIL_USER}>`,
      to: process.env.RECEIVER_EMAIL,
      subject: 'New Booking Request',
      html: output
    });
    res.send('<script>alert("Booking submitted successfully!"); window.location.href="/booking.html";</script>');
  } catch (err) {
    console.error(err);
    res.status(500).send('Booking failed. Try again later.');
  }
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Server started on http://localhost:${PORT}`));
